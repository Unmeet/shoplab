# ShopLab test scenarios

44 end-to-end scenarios to automate. Reset store data (POST /api/reset) before each run. The same list, with progress tracking, is on the Scenarios page of the site.

| ID | Area | Type | Priority | Scenario |
|---|---|---|---|---|
| SC-01 | Authentication | UI | High | Log in with valid credentials |
| SC-02 | Authentication | UI + API | High | Locked account is refused |
| SC-03 | Authentication | UI + API | Medium | Login pauses after 5 failed attempts |
| SC-04 | Authentication | UI | Medium | Slow login needs an explicit wait |
| SC-05 | Authentication | UI | High | Two-step login with an emailed code |
| SC-06 | Authentication | UI | High | Reset a forgotten password |
| SC-07 | Authentication | UI | Medium | Register a new account |
| SC-08 | Catalog | UI | High | Filter and sort the catalogue |
| SC-09 | Catalog | UI | Medium | Search suggestions with the keyboard |
| SC-10 | Catalog | UI + API | Low | Pagination covers every product once |
| SC-11 | Product | UI | Medium | Size must be chosen before adding to cart |
| SC-12 | Product | UI + API | High | Back-in-stock email |
| SC-13 | Cart | UI | High | Guest cart merges on login |
| SC-14 | Cart | UI + API | High | Coupon rules |
| SC-15 | Cart | UI + API | High | Totals add up |
| SC-16 | Checkout | UI | High | Checkout with a saved address |
| SC-17 | Checkout | UI | High | Declined card, then success |
| SC-18 | Checkout | UI + API | Medium | Server error at checkout |
| SC-19 | Orders | UI | High | Cancel a processing order |
| SC-20 | Orders | UI + API | High | Return a delivered order |
| SC-21 | Orders | UI | Medium | Buy again skips unavailable items |
| SC-22 | Orders | UI + API | Medium | Track an order without logging in |
| SC-23 | Account | UI + API | Medium | Manage the address book |
| SC-24 | Admin | API | High | Product lifecycle and permissions |
| SC-25 | Interruptions | UI | High | Cookie banner and newsletter popup |
| SC-26 | Resilience | UI + API | Medium | Chaos mode |
| SC-27 | Localisation | UI | Low | Switch currency |
| SC-28 | API | API | High | Negative contract tests |
| SC-29 | Elements | UI | High | Dependent dropdowns |
| SC-30 | Elements | UI | High | Custom calendar date picker |
| SC-31 | Elements | UI | Medium | Searchable and multi-select dropdowns |
| SC-32 | Elements | UI | Medium | Split OTP boxes, tags and limits |
| SC-33 | Elements | UI | High | Form validation with an error summary |
| SC-34 | Elements | UI | Medium | Visibility traps |
| SC-35 | Authentication | UI | High | Log in with an emailed code (split boxes) |
| SC-36 | Authentication | UI | High | ShopLab ID pop-up login |
| SC-37 | Catalog | UI | Medium | Quick view and the mini-cart drawer |
| SC-38 | Product | UI + API | High | Gift wrap and protection pricing |
| SC-39 | Product | UI + API | Medium | Delivery check by postal code |
| SC-40 | Checkout | UI | High | Rich checkout: billing, schedule and UPI |
| SC-41 | Checkout | UI | High | 3-D Secure check inside an iframe |
| SC-42 | Checkout | UI + API | Medium | Cash on delivery rules |
| SC-43 | Cart | UI | Medium | Save for later |
| SC-44 | Product | UI | Low | Gallery, lightbox and sticky add-to-cart |

## SC-01: Log in with valid credentials

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. Open #login.
2. Enter standard_user and Practice@123.
3. Select Log in.

**Expected results**

- The header shows “Hi, Sam”.
- The page goes to the shop.
- A token is stored and GET /api/auth/me returns 200.

## SC-02: Locked account is refused

**Area:** Authentication. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. Log in as locked_user with Practice@123.

**Expected results**

- An error says the account is locked.
- POST /api/auth/login returns 423 ACCOUNT_LOCKED.
- No token is stored.

## SC-03: Login pauses after 5 failed attempts

**Area:** Authentication. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Reset store data.

**Steps**

1. Log in as standard_user with a wrong password 5 times.
2. Try once more with the correct password.

**Expected results**

- Attempts 1–5 return 401; the 5th message says login is paused.
- Attempt 6 returns 429 TOO_MANY_ATTEMPTS with a Retry-After header, even with the right password.
- After 60 seconds the correct password works.

## SC-04: Slow login needs an explicit wait

**Area:** Authentication. **Type:** UI. **Priority:** Medium.

**Before you start:** Logged out.

**Steps**

1. Log in as slow_user.

**Expected results**

- The button shows “Logging in…” and is disabled for about 3 seconds.
- The user menu appears afterwards. A test with a 2-second fixed wait fails; an explicit wait passes.

## SC-05: Two-step login with an emailed code

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. Log in as otp_user.
2. Open the inbox for otp@shoplab.test in a new tab and read the code.
3. Enter a wrong code, then the right one.

**Expected results**

- The code step shows the masked address o***@shoplab.test.
- A wrong code shows how many attempts are left.
- Resend is disabled for 30 seconds with a countdown.
- The right code logs you in as Olu.

## SC-06: Reset a forgotten password

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Reset store data.

**Steps**

1. Select “Forgot your password?” and enter standard@shoplab.test.
2. Read the reset code in the inbox.
3. Set the new password NewPass@123.
4. Log in with the old password, then the new one.

**Expected results**

- The request page never says whether the email exists.
- A “password was changed” email arrives.
- The old password fails and the new one works.

## SC-07: Register a new account

**Area:** Authentication. **Type:** UI. **Priority:** Medium.

**Before you start:** Logged out.

**Steps**

1. Try username standard_user.
2. Try a weak password and mismatched confirmation.
3. Register with valid, unique details.

**Expected results**

- Each problem shows a message next to its field.
- A taken username returns 409.
- Success logs you in and a welcome email arrives.

## SC-08: Filter and sort the catalogue

**Area:** Catalog. **Type:** UI. **Priority:** High.

**Before you start:** None.

**Steps**

1. Tick Electronics.
2. Set max price to $100.
3. Sort by Price: low to high.

**Expected results**

- Every card is Electronics and costs $100 or less.
- Prices are in ascending order.
- Filter chips appear and removing one updates the results.

## SC-09: Search suggestions with the keyboard

**Area:** Catalog. **Type:** UI. **Priority:** Medium.

**Before you start:** None.

**Steps**

1. Type “bo” in the header search.
2. Press Arrow Down twice and Enter.

**Expected results**

- A list of up to 5 suggestions appears.
- The highlighted suggestion opens its product page.

## SC-10: Pagination covers every product once

**Area:** Catalog. **Type:** UI + API. **Priority:** Low.

**Before you start:** Reset store data.

**Steps**

1. Collect product names from every page of the shop.

**Expected results**

- The total matches meta.total from GET /api/products.
- No product appears twice.

## SC-11: Size must be chosen before adding to cart

**Area:** Product. **Type:** UI. **Priority:** Medium.

**Before you start:** None.

**Steps**

1. Open #product-5.
2. Select Add to cart without a size.
3. Choose M, set quantity 2, add again.

**Expected results**

- An error asks you to choose a size, and nothing is added.
- The cart badge shows 2.

## SC-12: Back-in-stock email

**Area:** Product. **Type:** UI + API. **Priority:** High.

**Before you start:** Reset store data.

**Steps**

1. Open #product-3 (sold out) and request an alert for your email.
2. As admin, raise its stock above 0.
3. Open the inbox.

**Expected results**

- A second request for the same email returns 409.
- A “back in stock” email arrives after the restock.

## SC-13: Guest cart merges on login

**Area:** Cart. **Type:** UI. **Priority:** High.

**Before you start:** Logged out with an empty cart.

**Steps**

1. Add two products as a guest.
2. Open the cart and choose Log in to check out.
3. Log in as standard_user.

**Expected results**

- The guest cart shows a subtotal and asks you to log in.
- After login a message says the items moved, and the account cart holds them.
- You land on checkout.

## SC-14: Coupon rules

**Area:** Cart. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged in, cart subtotal under $100.

**Steps**

1. Apply FLAT20, EXPIRED5, NOPE, then SAVE10.
2. Replace with FREESHIP.

**Expected results**

- FLAT20 fails with the minimum message; EXPIRED5 says expired; NOPE does not exist.
- SAVE10 takes 10% off the subtotal.
- FREESHIP makes shipping free.

## SC-15: Totals add up

**Area:** Cart. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged in with items in the cart.

**Steps**

1. Read every line of the order summary.
2. Call GET /api/cart.

**Expected results**

- Total = subtotal − discount + shipping + 8% tax on (subtotal − discount).
- UI values equal the API values.
- Standard shipping is free from $75.

## SC-16: Checkout with a saved address

**Area:** Checkout. **Type:** UI. **Priority:** High.

**Before you start:** Logged in as returning_user with items in the cart.

**Steps**

1. Go to checkout; keep the default Home address.
2. Choose Express, pay with 4111 1111 1111 1111.
3. Accept the terms and place the order.

**Expected results**

- The address form stays hidden while a saved address is selected.
- The confirmation shows an order number.
- An “Order # confirmed” email arrives for returning@shoplab.test.

## SC-17: Declined card, then success

**Area:** Checkout. **Type:** UI. **Priority:** High.

**Before you start:** Logged in with items in the cart.

**Steps**

1. Pay with 4000 0000 0000 0002.
2. Edit payment to 4111 1111 1111 1111 and retry.

**Expected results**

- The first attempt shows “card was declined” (402) and the cart is unchanged.
- The second attempt places the order.

## SC-18: Server error at checkout

**Area:** Checkout. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged in as error_user with items in the cart.

**Steps**

1. Complete checkout and place the order.

**Expected results**

- An error explains the payment service failed (500).
- The cart still holds every item.

## SC-19: Cancel a processing order

**Area:** Orders. **Type:** UI. **Priority:** High.

**Before you start:** Reset store data, logged in as returning_user.

**Steps**

1. Open order #1002.
2. Cancel it and confirm.

**Expected results**

- The status becomes cancelled.
- Stock for its products goes back up.
- A cancellation email arrives.

## SC-20: Return a delivered order

**Area:** Orders. **Type:** UI + API. **Priority:** High.

**Before you start:** Reset store data, logged in as returning_user.

**Steps**

1. Open order #1001 and request a return.
2. Choose “Other” without a comment, then add one.
3. Request again through the API.

**Expected results**

- The comment is required for “Other”.
- The status becomes return requested with RMA-1001, and an email arrives.
- The second request returns 409.

## SC-21: Buy again skips unavailable items

**Area:** Orders. **Type:** UI. **Priority:** Medium.

**Before you start:** Reset store data, logged in as returning_user. Order #1001 includes APIs Explained, which is out of stock.

**Steps**

1. Open order #1001 and select Buy again.

**Expected results**

- Available items are added to the cart.
- A message lists each skipped item and the reason.

## SC-22: Track an order without logging in

**Area:** Orders. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged out.

**Steps**

1. Open #track.
2. Enter 1001 with returning@shoplab.test.
3. Try 1001 with another email.

**Expected results**

- The status and delivery timeline appear.
- A wrong email says no order matches, without revealing that the order exists.

## SC-23: Manage the address book

**Area:** Account. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged in as standard_user.

**Steps**

1. Add an address, then a second one.
2. Make the second the default, edit it, delete the first.
3. Try adding a sixth address via the API.

**Expected results**

- The first address becomes the default automatically.
- Only one default exists at a time.
- The sixth address returns 409 ADDRESS_LIMIT.

## SC-24: Product lifecycle and permissions

**Area:** Admin. **Type:** API. **Priority:** High.

**Before you start:** Tokens for admin and standard_user.

**Steps**

1. POST a product as admin.
2. Search for it in the shop.
3. Try DELETE as standard_user, then as admin.
4. GET it again.

**Expected results**

- Create returns 201 with a Location header.
- It appears in shop search.
- Customer delete returns 403; admin delete returns 204; GET returns 404.

## SC-25: Cookie banner and newsletter popup

**Area:** Interruptions. **Type:** UI. **Priority:** High.

**Before you start:** Fresh browser profile.

**Steps**

1. Open the shop and wait 10 seconds.
2. Handle the cookie banner and popup.
3. In a second test, set localStorage before load to skip both.

**Expected results**

- The banner covers the bottom of the page until you choose.
- The popup appears once per browser.
- Pre-set storage keys (see Test settings) skip both.

## SC-26: Chaos mode

**Area:** Resilience. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Test settings open.

**Steps**

1. Set the failure rate to 30% and latency to 1500 ms.
2. Run a shopping test.

**Expected results**

- Some requests return 503 CHAOS_FAILURE.
- The product grid shows Try again on failure.
- Tests with retries and explicit waits still pass.

## SC-27: Switch currency

**Area:** Localisation. **Type:** UI. **Priority:** Low.

**Before you start:** None.

**Steps**

1. Choose INR in the currency menu.
2. Open a product and the checkout review.

**Expected results**

- Prices use ₹ at the fixed rate of 84 per USD.
- Checkout states the charge is made in USD.
- Orders and the API still store USD.

## SC-28: Negative contract tests

**Area:** API. **Type:** API. **Priority:** High.

**Before you start:** None.

**Steps**

1. Call GET /api/cart without a token, with “Bearer junk”, and with an expired token (expiresIn 10).
2. Call POST /api/products as a customer.
3. Send malformed JSON, a wrong method and an unknown path.

**Expected results**

- 401 AUTH_REQUIRED, INVALID_TOKEN and TOKEN_EXPIRED respectively.
- 403 FORBIDDEN.
- 400 MALFORMED_JSON, 405 METHOD_NOT_ALLOWED and 404 ROUTE_NOT_FOUND, all in the standard error format.

## SC-29: Dependent dropdowns

**Area:** Elements. **Type:** UI. **Priority:** High.

**Before you start:** Open #elements.

**Steps**

1. Check that State and City are disabled.
2. Choose India, then Gujarat, then Ahmedabad.
3. Change the country to United States.

**Expected results**

- State lists only Indian states; City lists only Gujarat cities.
- The output reads “Location: Ahmedabad, Gujarat, India”.
- Changing the country clears and disables City again.

## SC-30: Custom calendar date picker

**Area:** Elements. **Type:** UI. **Priority:** High.

**Before you start:** Open #elements.

**Steps**

1. Open the delivery date calendar.
2. Try to pick yesterday and a Sunday.
3. Move to next month and pick the 15th (or the next open day).

**Expected results**

- Past dates and Sundays are disabled.
- The previous-month button is disabled on the current month.
- The field shows the date as DD Mon YYYY and the calendar closes.

## SC-31: Searchable and multi-select dropdowns

**Area:** Elements. **Type:** UI. **Priority:** Medium.

**Before you start:** Open #elements.

**Steps**

1. Open the test tool dropdown, type “play”, press Arrow Down and Enter.
2. In Skills, add Python, Java and SQL, then remove Java with its × button and SQL with Backspace.

**Expected results**

- The tool button shows Playwright.
- Typing “zzz” shows “No matches”.
- The skills output reads “Skills: Python”, and chosen skills disappear from the list.

## SC-32: Split OTP boxes, tags and limits

**Area:** Elements. **Type:** UI. **Priority:** Medium.

**Before you start:** Open #elements.

**Steps**

1. Paste 246810 into the first OTP box and verify.
2. Type a wrong digit and verify again.
3. Add 6 tags, including a duplicate.
4. Tick 4 toppings.

**Expected results**

- The pasted code fills all 6 boxes and verifies.
- A wrong code shows an error.
- Duplicates and a 6th tag are refused with messages.
- After 3 toppings the rest are disabled.

## SC-33: Form validation with an error summary

**Area:** Elements. **Type:** UI. **Priority:** High.

**Before you start:** Open #elements.

**Steps**

1. Select Validate and submit with the form empty.
2. Select the first error link.
3. Fill every required field, including scrolling the terms to the end, and submit again.

**Expected results**

- A summary lists 9 problems, each with a message next to its field.
- The error link focuses the field.
- The output starts with “Submitted successfully” followed by the JSON values.

## SC-34: Visibility traps

**Area:** Elements. **Type:** UI. **Priority:** Medium.

**Before you start:** Open #elements and scroll to Visibility states.

**Steps**

1. For each of the 8 buttons, assert whether it is visible.
2. Try to click the covered button.
3. Click the button inside the scroll box and the one inside the closed details.

**Expected results**

- Your assertions match the answers table.
- Clicking the covered button fails or hits the overlay.
- The scroll-box and details buttons work once scrolled or opened.

## SC-35: Log in with an emailed code (split boxes)

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. On #login choose the “Email me a code” tab and enter standard@shoplab.test.
2. Read the code from the inbox (or GET /api/inbox).
3. Paste it into the first of the 6 boxes and log in.

**Expected results**

- The masked address s****@shoplab.test is shown.
- Pasting fills all 6 boxes; a partial code shows “Enter all 6 digits”.
- Resend is disabled for 30 seconds.
- You are logged in as Sam.

## SC-36: ShopLab ID pop-up login

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Logged out, pop-ups allowed.

**Steps**

1. Select “Continue with ShopLab ID”.
2. Switch to the new window, choose returning_user and select Continue without consent.
3. Tick the consent box and continue.

**Expected results**

- A separate window opens without the store header.
- Missing consent shows an error and the window stays open.
- The window closes and the original tab shows “Hi, Rae”.
- Cancel instead shows “sign-in was cancelled”.

## SC-37: Quick view and the mini-cart drawer

**Area:** Catalog. **Type:** UI. **Priority:** Medium.

**Before you start:** On the shop page.

**Steps**

1. Hover product 5 and open Quick view.
2. Add to cart without a size, then with size L.
3. Close the drawer with Escape, then reopen by adding another product and choose View cart.

**Expected results**

- Quick view asks for a size first.
- The mini-cart slides in listing the item, its options and the subtotal.
- Escape, ✕ and the backdrop all close it.
- Turning the mini-cart off in Test settings stops it opening.

## SC-38: Gift wrap and protection pricing

**Area:** Product. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged in, empty cart.

**Steps**

1. Open #product-1, choose Black, tick gift wrap with a message, choose 1-year protection, set quantity 2.
2. Add to cart and open the cart.
3. GET /api/cart.

**Expected results**

- Item total shows $286.76: 2 × (129.99 + 2.99 + 10.40).
- The cart line lists the colour, gift wrap, protection and gift message.
- The API returns unitPrice 143.38 and the options object.
- A gift message without gift wrap returns 400 from the API.

## SC-39: Delivery check by postal code

**Area:** Product. **Type:** UI + API. **Priority:** Medium.

**Before you start:** On any in-stock product page.

**Steps**

1. Check 12, 000000, 560009 and 560001.

**Expected results**

- 12 shows a format error.
- 000000 says we don’t deliver there.
- 560009 is remote: 2 extra days and no cash on delivery.
- 560001 lists three delivery dates that skip weekends.

## SC-40: Rich checkout: billing, schedule and UPI

**Area:** Checkout. **Type:** UI. **Priority:** High.

**Before you start:** Logged in as returning_user with items in the cart.

**Steps**

1. Choose Work, add delivery instructions, untick “billing same as shipping” and fill the billing address.
2. Turn on scheduled delivery, try a Sunday, then a weekday with the afternoon slot.
3. Pay by UPI: verify nobody@upi, then rae@okbank.
4. Use the Change links on the review step.

**Expected results**

- Billing fields are required only when shown.
- Sundays are refused and a slot is required.
- Unverified UPI IDs cannot continue.
- The review shows Work, the instructions, the billing address and the schedule, and each Change link opens its step.

## SC-41: 3-D Secure check inside an iframe

**Area:** Checkout. **Type:** UI. **Priority:** High.

**Before you start:** At the payment step.

**Steps**

1. Pay with 4000 0000 0000 3220 and place the order.
2. Inside the bank frame enter 111111.
3. Place again and enter 123456.

**Expected results**

- A modal opens with the bank page in an iframe showing the amount.
- The wrong code shows “verification code was wrong” and no order is created.
- The right code places the order and the confirmation says Visa ending 3220.

## SC-42: Cash on delivery rules

**Area:** Checkout. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged in.

**Steps**

1. Check out a cart over $200 and look at the payment options.
2. Check out a small cart and pay on delivery.

**Expected results**

- Cash on delivery is disabled over $200 and for postal codes ending in 9.
- A $1.99 fee appears in the summary, the review and the order total.
- The API returns 409 COD_NOT_AVAILABLE for an ineligible order.

## SC-43: Save for later

**Area:** Cart. **Type:** UI. **Priority:** Medium.

**Before you start:** Logged in with two items in the cart.

**Steps**

1. Select Save for later on one item.
2. Move it back to the cart.
3. Save it again and remove it from the saved list.

**Expected results**

- The item leaves the cart totals and appears under “Saved for later”.
- Moving it back keeps its options.
- Removing it leaves both lists without it.

## SC-44: Gallery, lightbox and sticky add-to-cart

**Area:** Product. **Type:** UI. **Priority:** Low.

**Before you start:** Open #product-1.

**Steps**

1. Hover each gallery thumbnail, then open the main image.
2. Use the arrow keys in the lightbox.
3. Scroll past the Add to cart button and use the sticky bar.

**Expected results**

- The main image follows the thumbnails.
- The lightbox counter reads “3 / 4” and wraps around.
- The sticky bar appears only after the main button scrolls out of view and adds the item with the chosen options.

