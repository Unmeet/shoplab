# ShopLab test scenarios

28 end-to-end scenarios to automate. Reset store data (POST /api/reset) before each run. The same list, with progress tracking, is on the Scenarios page of the site.

| ID | Area | Type | Priority | Scenario |
|---|---|---|---|---|
| SC-01 | Authentication | UI | High | Log in with valid credentials |
| SC-02 | Authentication | UI + API | High | Locked account is refused |
| SC-03 | Authentication | UI + API | Medium | Login pauses after 5 failed attempts |
| SC-04 | Authentication | UI | Medium | Slow login needs an explicit wait |
| SC-05 | Authentication | UI | High | Two-step login with an emailed code |
| SC-06 | Authentication | UI | High | Reset a forgotten password |
| SC-07 | Authentication | UI | Medium | Register a new account |
| SC-08 | Catalog | UI | High | Filter and sort the catalogue |
| SC-09 | Catalog | UI | Medium | Search suggestions with the keyboard |
| SC-10 | Catalog | UI + API | Low | Pagination covers every product once |
| SC-11 | Product | UI | Medium | Size must be chosen before adding to cart |
| SC-12 | Product | UI + API | High | Back-in-stock email |
| SC-13 | Cart | UI | High | Guest cart merges on login |
| SC-14 | Cart | UI + API | High | Coupon rules |
| SC-15 | Cart | UI + API | High | Totals add up |
| SC-16 | Checkout | UI | High | Checkout with a saved address |
| SC-17 | Checkout | UI | High | Declined card, then success |
| SC-18 | Checkout | UI + API | Medium | Server error at checkout |
| SC-19 | Orders | UI | High | Cancel a processing order |
| SC-20 | Orders | UI + API | High | Return a delivered order |
| SC-21 | Orders | UI | Medium | Buy again skips unavailable items |
| SC-22 | Orders | UI + API | Medium | Track an order without logging in |
| SC-23 | Account | UI + API | Medium | Manage the address book |
| SC-24 | Admin | API | High | Product lifecycle and permissions |
| SC-25 | Interruptions | UI | High | Cookie banner and newsletter popup |
| SC-26 | Resilience | UI + API | Medium | Chaos mode |
| SC-27 | Localisation | UI | Low | Switch currency |
| SC-28 | API | API | High | Negative contract tests |

## SC-01: Log in with valid credentials

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. Open #login.
2. Enter standard_user and Practice@123.
3. Select Log in.

**Expected results**

- The header shows “Hi, Sam”.
- The page goes to the shop.
- A token is stored and GET /api/auth/me returns 200.

## SC-02: Locked account is refused

**Area:** Authentication. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. Log in as locked_user with Practice@123.

**Expected results**

- An error says the account is locked.
- POST /api/auth/login returns 423 ACCOUNT_LOCKED.
- No token is stored.

## SC-03: Login pauses after 5 failed attempts

**Area:** Authentication. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Reset store data.

**Steps**

1. Log in as standard_user with a wrong password 5 times.
2. Try once more with the correct password.

**Expected results**

- Attempts 1–5 return 401; the 5th message says login is paused.
- Attempt 6 returns 429 TOO_MANY_ATTEMPTS with a Retry-After header, even with the right password.
- After 60 seconds the correct password works.

## SC-04: Slow login needs an explicit wait

**Area:** Authentication. **Type:** UI. **Priority:** Medium.

**Before you start:** Logged out.

**Steps**

1. Log in as slow_user.

**Expected results**

- The button shows “Logging in…” and is disabled for about 3 seconds.
- The user menu appears afterwards. A test with a 2-second fixed wait fails; an explicit wait passes.

## SC-05: Two-step login with an emailed code

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Logged out.

**Steps**

1. Log in as otp_user.
2. Open the inbox for otp@shoplab.test in a new tab and read the code.
3. Enter a wrong code, then the right one.

**Expected results**

- The code step shows the masked address o***@shoplab.test.
- A wrong code shows how many attempts are left.
- Resend is disabled for 30 seconds with a countdown.
- The right code logs you in as Olu.

## SC-06: Reset a forgotten password

**Area:** Authentication. **Type:** UI. **Priority:** High.

**Before you start:** Reset store data.

**Steps**

1. Select “Forgot your password?” and enter standard@shoplab.test.
2. Read the reset code in the inbox.
3. Set the new password NewPass@123.
4. Log in with the old password, then the new one.

**Expected results**

- The request page never says whether the email exists.
- A “password was changed” email arrives.
- The old password fails and the new one works.

## SC-07: Register a new account

**Area:** Authentication. **Type:** UI. **Priority:** Medium.

**Before you start:** Logged out.

**Steps**

1. Try username standard_user.
2. Try a weak password and mismatched confirmation.
3. Register with valid, unique details.

**Expected results**

- Each problem shows a message next to its field.
- A taken username returns 409.
- Success logs you in and a welcome email arrives.

## SC-08: Filter and sort the catalogue

**Area:** Catalog. **Type:** UI. **Priority:** High.

**Before you start:** None.

**Steps**

1. Tick Electronics.
2. Set max price to $100.
3. Sort by Price: low to high.

**Expected results**

- Every card is Electronics and costs $100 or less.
- Prices are in ascending order.
- Filter chips appear and removing one updates the results.

## SC-09: Search suggestions with the keyboard

**Area:** Catalog. **Type:** UI. **Priority:** Medium.

**Before you start:** None.

**Steps**

1. Type “bo” in the header search.
2. Press Arrow Down twice and Enter.

**Expected results**

- A list of up to 5 suggestions appears.
- The highlighted suggestion opens its product page.

## SC-10: Pagination covers every product once

**Area:** Catalog. **Type:** UI + API. **Priority:** Low.

**Before you start:** Reset store data.

**Steps**

1. Collect product names from every page of the shop.

**Expected results**

- The total matches meta.total from GET /api/products.
- No product appears twice.

## SC-11: Size must be chosen before adding to cart

**Area:** Product. **Type:** UI. **Priority:** Medium.

**Before you start:** None.

**Steps**

1. Open #product-5.
2. Select Add to cart without a size.
3. Choose M, set quantity 2, add again.

**Expected results**

- An error asks you to choose a size, and nothing is added.
- The cart badge shows 2.

## SC-12: Back-in-stock email

**Area:** Product. **Type:** UI + API. **Priority:** High.

**Before you start:** Reset store data.

**Steps**

1. Open #product-3 (sold out) and request an alert for your email.
2. As admin, raise its stock above 0.
3. Open the inbox.

**Expected results**

- A second request for the same email returns 409.
- A “back in stock” email arrives after the restock.

## SC-13: Guest cart merges on login

**Area:** Cart. **Type:** UI. **Priority:** High.

**Before you start:** Logged out with an empty cart.

**Steps**

1. Add two products as a guest.
2. Open the cart and choose Log in to check out.
3. Log in as standard_user.

**Expected results**

- The guest cart shows a subtotal and asks you to log in.
- After login a message says the items moved, and the account cart holds them.
- You land on checkout.

## SC-14: Coupon rules

**Area:** Cart. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged in, cart subtotal under $100.

**Steps**

1. Apply FLAT20, EXPIRED5, NOPE, then SAVE10.
2. Replace with FREESHIP.

**Expected results**

- FLAT20 fails with the minimum message; EXPIRED5 says expired; NOPE does not exist.
- SAVE10 takes 10% off the subtotal.
- FREESHIP makes shipping free.

## SC-15: Totals add up

**Area:** Cart. **Type:** UI + API. **Priority:** High.

**Before you start:** Logged in with items in the cart.

**Steps**

1. Read every line of the order summary.
2. Call GET /api/cart.

**Expected results**

- Total = subtotal − discount + shipping + 8% tax on (subtotal − discount).
- UI values equal the API values.
- Standard shipping is free from $75.

## SC-16: Checkout with a saved address

**Area:** Checkout. **Type:** UI. **Priority:** High.

**Before you start:** Logged in as returning_user with items in the cart.

**Steps**

1. Go to checkout; keep the default Home address.
2. Choose Express, pay with 4111 1111 1111 1111.
3. Accept the terms and place the order.

**Expected results**

- The address form stays hidden while a saved address is selected.
- The confirmation shows an order number.
- An “Order # confirmed” email arrives for returning@shoplab.test.

## SC-17: Declined card, then success

**Area:** Checkout. **Type:** UI. **Priority:** High.

**Before you start:** Logged in with items in the cart.

**Steps**

1. Pay with 4000 0000 0000 0002.
2. Edit payment to 4111 1111 1111 1111 and retry.

**Expected results**

- The first attempt shows “card was declined” (402) and the cart is unchanged.
- The second attempt places the order.

## SC-18: Server error at checkout

**Area:** Checkout. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged in as error_user with items in the cart.

**Steps**

1. Complete checkout and place the order.

**Expected results**

- An error explains the payment service failed (500).
- The cart still holds every item.

## SC-19: Cancel a processing order

**Area:** Orders. **Type:** UI. **Priority:** High.

**Before you start:** Reset store data, logged in as returning_user.

**Steps**

1. Open order #1002.
2. Cancel it and confirm.

**Expected results**

- The status becomes cancelled.
- Stock for its products goes back up.
- A cancellation email arrives.

## SC-20: Return a delivered order

**Area:** Orders. **Type:** UI + API. **Priority:** High.

**Before you start:** Reset store data, logged in as returning_user.

**Steps**

1. Open order #1001 and request a return.
2. Choose “Other” without a comment, then add one.
3. Request again through the API.

**Expected results**

- The comment is required for “Other”.
- The status becomes return requested with RMA-1001, and an email arrives.
- The second request returns 409.

## SC-21: Buy again skips unavailable items

**Area:** Orders. **Type:** UI. **Priority:** Medium.

**Before you start:** Reset store data, logged in as returning_user. Order #1001 includes APIs Explained, which is out of stock.

**Steps**

1. Open order #1001 and select Buy again.

**Expected results**

- Available items are added to the cart.
- A message lists each skipped item and the reason.

## SC-22: Track an order without logging in

**Area:** Orders. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged out.

**Steps**

1. Open #track.
2. Enter 1001 with returning@shoplab.test.
3. Try 1001 with another email.

**Expected results**

- The status and delivery timeline appear.
- A wrong email says no order matches, without revealing that the order exists.

## SC-23: Manage the address book

**Area:** Account. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Logged in as standard_user.

**Steps**

1. Add an address, then a second one.
2. Make the second the default, edit it, delete the first.
3. Try adding a sixth address via the API.

**Expected results**

- The first address becomes the default automatically.
- Only one default exists at a time.
- The sixth address returns 409 ADDRESS_LIMIT.

## SC-24: Product lifecycle and permissions

**Area:** Admin. **Type:** API. **Priority:** High.

**Before you start:** Tokens for admin and standard_user.

**Steps**

1. POST a product as admin.
2. Search for it in the shop.
3. Try DELETE as standard_user, then as admin.
4. GET it again.

**Expected results**

- Create returns 201 with a Location header.
- It appears in shop search.
- Customer delete returns 403; admin delete returns 204; GET returns 404.

## SC-25: Cookie banner and newsletter popup

**Area:** Interruptions. **Type:** UI. **Priority:** High.

**Before you start:** Fresh browser profile.

**Steps**

1. Open the shop and wait 10 seconds.
2. Handle the cookie banner and popup.
3. In a second test, set localStorage before load to skip both.

**Expected results**

- The banner covers the bottom of the page until you choose.
- The popup appears once per browser.
- Pre-set storage keys (see Test settings) skip both.

## SC-26: Chaos mode

**Area:** Resilience. **Type:** UI + API. **Priority:** Medium.

**Before you start:** Test settings open.

**Steps**

1. Set the failure rate to 30% and latency to 1500 ms.
2. Run a shopping test.

**Expected results**

- Some requests return 503 CHAOS_FAILURE.
- The product grid shows Try again on failure.
- Tests with retries and explicit waits still pass.

## SC-27: Switch currency

**Area:** Localisation. **Type:** UI. **Priority:** Low.

**Before you start:** None.

**Steps**

1. Choose INR in the currency menu.
2. Open a product and the checkout review.

**Expected results**

- Prices use ₹ at the fixed rate of 84 per USD.
- Checkout states the charge is made in USD.
- Orders and the API still store USD.

## SC-28: Negative contract tests

**Area:** API. **Type:** API. **Priority:** High.

**Before you start:** None.

**Steps**

1. Call GET /api/cart without a token, with “Bearer junk”, and with an expired token (expiresIn 10).
2. Call POST /api/products as a customer.
3. Send malformed JSON, a wrong method and an unknown path.

**Expected results**

- 401 AUTH_REQUIRED, INVALID_TOKEN and TOKEN_EXPIRED respectively.
- 403 FORBIDDEN.
- 400 MALFORMED_JSON, 405 METHOD_NOT_ALLOWED and 404 ROUTE_NOT_FOUND, all in the standard error format.

